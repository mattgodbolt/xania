/*************************************************************************/
/*  Xania (M)ulti(U)ser(D)ungeon server source code                      */
/*  (C) 1995-2000 Xania Development Team                                    */
/*  See the header to file: merc.h for original code copyrights          */
/*                                                                       */
/*  clan.c: organised player clans                                       */
/*                                                                       */
/*************************************************************************/


/* $Id: clan.c,v 1.6 2000/02/27 23:08:15 rob Exp $ */

#include <stdlib.h>
#include <stdio.h>
#if defined(riscos)
#include "sys/time.h"
#else
#include <sys/time.h>
#endif
#include "merc.h"

DECLARE_DO_FUN(do_afk);

/* User servicable bits... you will also need to change the NUM_CLANS in clan.h */

const CLAN clantable[NUM_CLANS] = {


   {
      "Keepers of the Lore", "|p(Lore)|w ", 'C',  /*clan 67 */
      {
         "a novice", "an initiate", "a Loreprotector",
         "a Lorebinder", "the Loremaster"       }
      ,
      30151, 30151  /* keep courtyard */
   }
   , /* Keepers of the Lore */


   {
      "Disciples of the Wyrm", "|p(Wyrm)|w ", 'B',  /*clan 66 */
      {
         "a neophyte", "an acolyte", "a priest",
         "a high priest", "the Preceptor"       }
      ,
      30102, 30102  /* courtyard */
   }
   , /* Disciples of the Wyrm */

   {
      "Implementor", "", 'D',  /* clan 68 */
      {
         "", "", "",
         "Implementor", ""       }
      ,
      30002, 0
   }
   , /* End IMP */

   {
      "One-eyed Snakes", "|c(O-II-S)|w ", 'O', /* clan 79 */
      {
         "a member", "a mini-snake", "a major-snake",
         "a python", "the One-Eyed Trouser Snake"       }
      ,
      30004, 0
   }  /* OES */

}; /* end clantable */

/* End user servicable bits */

void do_clantalk( CHAR_DATA *ch, char *argument ) {

   char buf[MAX_STRING_LENGTH];
   int candoit = 0;
   DESCRIPTOR_DATA *d;
   PCCLAN *OrigClan;

   if (IS_NPC(ch))
      {
	 if (ch->desc->original)
	    OrigClan = ch->desc->original->pcdata->pcclan;
	 else
	    OrigClan = NULL;
      }
   else
      OrigClan = ch->pcdata->pcclan;

   if (OrigClan == NULL) {
      send_to_char( "You are not a member of a clan.\n\r", ch);
      return; /* Disallow mortal PC's with no clan */
   } /* if ch->pcclan */

   if (IS_SET(ch->comm, COMM_QUIET)) {
     send_to_char("You must remove quiet mode first.\n\r", ch);
     return;
   }

   if (argument[0] == '\0' || !OrigClan->channelflags) {
      /* They want to turn it on/off */
      OrigClan->channelflags ^= CLANCHANNEL_ON;
      sprintf( buf, "Clan channel now %s\n\r", (OrigClan->channelflags & CLANCHANNEL_ON)
      ? "on" : "off" );
      send_to_char( buf, ch );
      return;
   }

   /* Next check to see if a CLAN_HERO or CLAN_LEADER is on first */

   for ( d = descriptor_list ; (d && !candoit); d=d->next )
      {
      CHAR_DATA *vix;
      vix = d->original ? d->original : d->character;

	 if (    vix
	      && d->character
	      && vix->pcdata->pcclan
	      && (vix->pcdata->pcclan->clan->clanchar ==
		 OrigClan->clan->clanchar)
	      && (vix->pcdata->pcclan->clanlevel >= CLAN_HERO)
	      && !IS_SET(vix->comm, COMM_QUIET) )
	    candoit = 1; /* Yeah we can do it! */
   } /* for all descriptors */

   if (!candoit) {
      send_to_char("Your clan lacks the necessary broadcast nexus, causing your vain telepathy to\n\rbe lost upon the winds.\n\r", ch);
      return;
   }

   if (OrigClan->channelflags & CLANCHANNEL_NOCHANNED) {
      send_to_char("Your clan channel priviledges have been revoked!\n\r", ch);
      return;
   }

   if (IS_SET(ch->act, PLR_AFK) )
      do_afk(ch, NULL);

   if (!OrigClan->channelflags)
   {
      OrigClan->channelflags ^= CLANCHANNEL_ON;
      sprintf( buf, "Clan channel now %s\n\r", (OrigClan->channelflags & CLANCHANNEL_ON)
      ? "on" : "off" );
      send_to_char( buf, ch );
   }

   /* Right here we go - tell all members of the clan the message */
   for ( d = descriptor_list ; d ; d=d->next ) {
      CHAR_DATA *vix;
      vix = d->original ? d->original : d->character;

      if ( (d->connected==CON_PLAYING) && (vix->pcdata->pcclan)
      && (vix->pcdata->pcclan->clan->clanchar ==
	  OrigClan->clan->clanchar)
      && (vix->pcdata->pcclan->channelflags & CLANCHANNEL_ON)
      && !IS_SET(vix->comm, COMM_QUIET)
      /* || they're an IMM snooping the channels */ )
      {
         sprintf(buf, "|G<%s> %s|w\n\r", can_see(d->character, ch)? ch->name : "Someone", argument);
         send_to_char( buf, d->character );
      } /* If they can see the message */
   } /* for all descriptors */

} /* do_clanchannel */

void do_noclanchan( CHAR_DATA *ch, char *argument ) {
   char buf[MAX_STRING_LENGTH];
   CHAR_DATA *victim;

   /* Check for ability to noclanchan */
   if (IS_NPC(ch))
      return;

   if( (get_trust(ch) > (MAX_LEVEL-5) ) ||
   ( ( ch->pcdata->pcclan != NULL) &&
   (ch->pcdata->pcclan->clanlevel > CLAN_HERO) ) )
   {
   }
   else
   {
      send_to_char( "Huh?\n\r", ch);
      return;
   }

   victim = get_char_world(ch, argument);
   if ( (victim == NULL) || IS_NPC(victim) ) {
      send_to_char( "They're not here.\n\r", ch);
      return;
   } /* If can't find victim */

   /* Check if victim is same clan, and not higher status */

   if ( (victim->pcdata->pcclan == NULL) /* If the victim is not in any clan */
   || (victim->pcdata->pcclan->clan->clanchar != ch->pcdata->pcclan->clan->clanchar) /* or in a different clan */
   || (victim->pcdata->pcclan->clanlevel > ch->pcdata->pcclan->clanlevel)) /* or they're a higher rank */
   {
      sprintf( buf, "You can't noclanchan %s!\n\r", victim->name );
      send_to_char( buf, ch );
      return;
   }

   if (victim == ch)
   {
      send_to_char ( "You cannot noclanchannel yourself.\n\r", ch);
      return;
   }

   /* If we get here everything is ok */

   victim->pcdata->pcclan->channelflags ^= CLANCHANNEL_NOCHANNED; /* Change the victim's flags */

   /* Tell the char how things went */
   sprintf(buf, "You have %sed %s's clan channel priviledges.\n\r",
   (victim->pcdata->pcclan->channelflags & CLANCHANNEL_NOCHANNED)? "revok" : "reinstat",
   victim->name );
   send_to_char( buf, ch );

   /* Inform the hapless victim */
   sprintf(buf, "%s has %sed your clan channel priviledges.\n\r",
   ch->name,
   (victim->pcdata->pcclan->channelflags & CLANCHANNEL_NOCHANNED)? "revok" : "reinstat" );
   buf[0] = UPPER(buf[0]);
   send_to_char( buf, victim );
} /* do_noclanchan */

void do_member( CHAR_DATA *ch, char *argument ) {
   char buf[MAX_STRING_LENGTH];
   char buf2[MAX_STRING_LENGTH];
   PCCLAN *newpcclan;
   CHAR_DATA *victim;

   /* Check for ability to member */

   if (IS_NPC(ch)) return;

   if ((ch->pcdata->pcclan == NULL) || (ch->pcdata->pcclan->clanlevel < CLAN_LEADER)) {
      send_to_char( "Huh?\n\r", ch); /* Cheesy cheat */
      return;
   } /* If not priveledged enough */

   argument = one_argument(argument, &buf2); /* Get the command */
   if (buf2[0] != '+' && buf2[0] != '-') {
      send_to_char( "Usage:\n\r       member + <character name>\n\r       member - <character name>\n\r", ch);
      return;
   }

   victim = get_char_room(ch,argument);
   if ( (victim == NULL) || IS_NPC(victim) ) {
      send_to_char( "You can't see them here.\n\r", ch);
      return;
   }

   if (victim == ch) {
      send_to_char( "What kind of wally are you?  You can't do that!\n\r", ch );
      return;
   }
   if (get_trust(victim) > get_trust(ch)) {
      sprintf( buf, "You cannot do that to %s.\n\r", victim->name);
      return;
   }

   if (buf2[0] == '+') {
      /* Adding a new member of the clan */
      if (victim->pcdata->pcclan) { /* The person is *already* in a clan */
         if (victim->pcdata->pcclan->clan->clanchar == ch->pcdata->pcclan->clan->clanchar) {
            /* Leader is trying to 'member +' a person who is already a memeber of their
                       clan.  They're probably trying to promote the person in question */
            sprintf( buf, "%s is already a member of the %s.\n\rUse 'promote' to promote characters.\n\r", victim->name, ch->pcdata->pcclan->clan->name);
            send_to_char( buf, ch );
            return;
         }
         else {
            /* In another clan ! */
            sprintf( buf, "%s is a member of the %s.\n\rThey must leave that clan first.\n\r", victim->name, ch->pcdata->pcclan->clan->name);
            send_to_char(buf, ch);
            return;
         } /* in your clan? */
      } /* if victim already in a clan */
      newpcclan = (PCCLAN *) alloc_mem(sizeof(PCCLAN));
      newpcclan->clan = ch->pcdata->pcclan->clan;
      newpcclan->clanlevel = CLAN_MEMBER;
      newpcclan->channelflags = CLANCHANNEL_ON;
      victim->pcdata->pcclan = newpcclan; /* dan-ar! */
      sprintf(buf, "%s welcomes %s to the %s", ch->name, victim->name, ch->pcdata->pcclan->clan->name);
      act( buf, ch, NULL, victim, TO_NOTVICT);
      sprintf( buf, "You have become %s of the %s.\n\r",
      ch->pcdata->pcclan->clan->levelname[CLAN_MEMBER],
      ch->pcdata->pcclan->clan->name );
      send_to_char( buf, victim );
      sprintf( buf, "You welcome %s as %s of the %s.\n\r",
      victim->name,
      ch->pcdata->pcclan->clan->levelname[CLAN_MEMBER],
      ch->pcdata->pcclan->clan->name );
      send_to_char( buf, ch);
   }
   else { /* End adding member */
      /* Removing a person from a clan */
      if ( (victim->pcdata->pcclan == NULL) ||
      (victim->pcdata->pcclan->clan->clanchar != ch->pcdata->pcclan->clan->clanchar) ) {
         sprintf( buf, "%s is not a member of your clan.\n\r", victim->name );
         send_to_char( buf, ch );
         return;
      } /* If not in clan */
      free_mem(victim->pcdata->pcclan, sizeof(PCCLAN));
      victim->pcdata->pcclan = NULL;
      sprintf(buf, "%s removes %s from the %s", ch->name, victim->name, ch->pcdata->pcclan->clan->name);
      act( buf, ch, NULL, victim, TO_NOTVICT);
      sprintf( buf, "You have been discharged from the %s.\n\r",
      ch->pcdata->pcclan->clan->name );
      send_to_char( buf, victim );
      sprintf( buf, "You remove %s from the %s.\n\r",
      victim->name,
      ch->pcdata->pcclan->clan->name );
      send_to_char( buf, ch);
   } /* ..else */
} /* do_member */

void mote( CHAR_DATA *ch, char *argument, int add ) {
   char buf[MAX_STRING_LENGTH];
   CHAR_DATA *victim;

   /* Check for ability to *mote */

   if (IS_NPC(ch)) return;

   if ((ch->pcdata->pcclan == NULL) || (ch->pcdata->pcclan->clanlevel < CLAN_LEADER)) {
      send_to_char( "Huh?\n\r", ch); /* Cheesy cheat */
      return;
   } /* If not priveledged enough */

   victim = get_char_room(ch,argument);
   if (victim == NULL) {
      send_to_char( "You can't see them here.\n\r", ch);
      return;
   } /* can see? */

   if (victim == ch) {
      send_to_char( "What kind of wally are you?  You can't do that!\n\r", ch );
      return;
   }

   if ( (victim->pcdata->pcclan == NULL) ||
   (victim->pcdata->pcclan->clan->clanchar != ch->pcdata->pcclan->clan->clanchar) ) {
      send_to_char( "You don't have authority to promote or demote them.\n\r", ch );
      return;
   }

   /* Idiot-proofing */
   if ((victim->pcdata->pcclan->clanlevel+add) > CLAN_HERO) {
      sprintf( buf, "You cannot make %s into another leader.\n\r", victim->name );
      send_to_char( buf, ch);
      return;
   }
   if ((victim->pcdata->pcclan->clanlevel+add) < CLAN_MEMBER) {
      send_to_char( "You can't demote below member status.\n\r", ch );
      return;
   }

   victim->pcdata->pcclan->clanlevel += add;
   sprintf( buf, "$n is now %s of the %s.",
   victim->pcdata->pcclan->clan->levelname[victim->pcdata->pcclan->clanlevel],
   victim->pcdata->pcclan->clan->name );
   act( buf, victim, NULL, NULL, TO_ROOM );
   sprintf( buf, "You are now %s of the %s.\n\r",
   victim->pcdata->pcclan->clan->levelname[victim->pcdata->pcclan->clanlevel],
   victim->pcdata->pcclan->clan->name );
   send_to_char( buf, victim );
} /* c'est le end */

void do_promote( CHAR_DATA *ch, char *argument ) {
   mote(ch,argument,1);
}

void do_demote( CHAR_DATA *ch, char *argument ) {
   mote(ch,argument,-1);
}

void do_clanwho( CHAR_DATA *ch, char *argument ) {
   DESCRIPTOR_DATA *d;
   CHAR_DATA *wch;
   char buf[MAX_STRING_LENGTH];

   if (IS_NPC(ch))
      return;

   if (!ch->pcdata->pcclan) {
      send_to_char( "You have no clan.\n\r", ch );
      return;
   }

   send_to_char( "|gCharacter name     |c|||g Clan level|w\n\r", ch);
   send_to_char( "|c-------------------+-------------------------------|w\n\r",
   ch);
   for (d = descriptor_list ; d ; d=d->next) {
      if (d->connected == CON_PLAYING) {
         wch = (d->original) ? (d->original) : d->character;
         if ( (can_see(ch,wch)) && (wch->pcdata->pcclan) &&
         (wch->pcdata->pcclan->clan->clanchar ==
         ch->pcdata->pcclan->clan->clanchar) ) {
            sprintf(buf, "%-19s|c|||w %s\n\r", wch->name,
            wch->pcdata->pcclan->clan->levelname[wch->pcdata->pcclan->clanlevel]);
            send_to_char( buf, ch );
         }
      }
   }
}

/*
 *  Oh well, this one _had_ to be put in some time. Faramir.
 */

void do_clanset ( CHAR_DATA *ch, char *argument) {

   char buf[MAX_STRING_LENGTH];
   char buf2[MAX_STRING_LENGTH];
   char arg1[MAX_INPUT_LENGTH];
   char marker;
   int iClan;
   int count = 0; /* Stops erroneous warning */
   CHAR_DATA *victim;
   PCCLAN *newpcclan;

   argument = one_argument(argument, arg1);

   if (arg1[0] == '\0') {

      send_to_char("Syntax: clanset {+/-}  <player> <clan>\n\r        clanset leader <player>\n\r", ch);
      return;
   }

   if ( ( arg1[0] == '+') || ( arg1[0] == '-' ) ) {
      marker = arg1[0];
      argument = one_argument(argument, arg1);

      if (arg1[0] == '\0') {
	 send_to_char("You must provide a valid player name.\n\r", ch);
	 return;
      }

      victim = get_char_world (ch, arg1);
      if (( victim == NULL ) || (IS_NPC(victim)) ) {
	 send_to_char("They're not here.\n\r", ch);
	 return;
      }

      if ( (get_trust(victim)) > get_trust(ch)) {
	 send_to_char("You do not have the powers to do that.\n\r", ch);
	 return;
      }

      if (marker == '+') {

      argument = one_argument (argument, arg1);

      if (arg1[0] == '\0') {
	 send_to_char("You must provide a valid clan name.\n\r", ch);
	 return;
      }

      iClan = -1;
      for( count = 0; count < NUM_CLANS; count++)
	 if (is_name(arg1, clantable[count].name)) {
	    iClan = count;
	    break;
	 }
      if ( (iClan == -1) ||
	   (!str_prefix(arg1, "Implementor")
	    && get_trust(ch) < IMPLEMENTOR  ) ) {
	 send_to_char("That is not a valid clan name.\n\r",ch);
	 send_to_char("Do 'help clanlist' to see those available.\n\r", ch);
	 return;
      }

      }
      switch (marker) {

      case '+': {        /* make someone a member of a clan */

	 if (victim->pcdata->pcclan) {
	    sprintf(buf, "%s is already in a clan.\n\r", victim->name);
	    send_to_char(buf, ch);
	    return;
	 }

	 newpcclan = (PCCLAN *) alloc_mem(sizeof(PCCLAN));
	 newpcclan->clan          = (CLAN *)&clantable[count];
	 newpcclan->clanlevel     = CLAN_MEMBER;
	 newpcclan->channelflags  = CLANCHANNEL_ON;
	 victim->pcdata->pcclan   = newpcclan;
	 sprintf( buf, "You set %s as %s of the %s.\n\r",
		  victim->name,
		  victim->pcdata->pcclan->clan->levelname[CLAN_MEMBER],
		  victim->pcdata->pcclan->clan->name );
	 send_to_char( buf, ch);
	 return;
	 break;
      }

      /* Removing a person from a clan */

      case '-': {
	 if ( (victim->pcdata->pcclan == NULL)) {
 	    sprintf( buf, "%s is not a member of a clan.\n\r", victim->name );
	    send_to_char( buf, ch );
	    return;
	 }
	 sprintf(buf2, victim->pcdata->pcclan->clan->name);

	 free_mem(victim->pcdata->pcclan, sizeof(PCCLAN));
	 victim->pcdata->pcclan = NULL;
	 sprintf( buf, "You remove %s from the %s.\n\r",
		  victim->name, buf2);
	 send_to_char( buf, ch);
	 return;

      }

      }
   }

   if (!str_prefix(arg1, "leader")) {

      argument = one_argument(argument, arg1);
      if (arg1[0] == '\0') {
	 send_to_char("You must provide a valid player name.\n\r", ch);
	 return;
      }
      victim = get_char_world(ch, arg1);
      if ( (victim == NULL) || (IS_NPC(victim)) ) {
	 send_to_char("They're not here.\n\r", ch);
	 return;
      }

      if ( (get_trust(victim)) > get_trust(ch)) {
	 send_to_char("You do not have the powers to do that.\n\r", ch);
	 return;
	 }

      if (victim->pcdata->pcclan == NULL) {
	 sprintf(buf, "%s is not in a clan.\n\r",
		 victim->name);
	 send_to_char(buf, ch);
	 return;
      }

      victim->pcdata->pcclan->clanlevel = CLAN_LEADER;
      send_to_char("Ok.\n\r", ch);
	 return;
   }


   send_to_char("Syntax: clanset {+/-}  <player> <clan>\n\r        clanset leader <player>\n\r", ch);
      return;


}




/*
umm..has to check descriptor list for clan rank of all present
         and in that particular clan. Has to do this every time
         someone uses channel?
         if so then channel  is_active
         else
         send_to_char("Your clan lacks the necessary broadcast nexus, causing your vain telepathy is lost upon the winds.\n\r");


         And what if ldr/ldr -1 is invisible?
         a member would always be able to tell if a member of
         higher status was logged on. - tough! mrg

Cool     basic reasoning for channs: the Gods support a telepathic framework for the main,
Cool     public channels. All mortals have a certain ability in telepathy which enables them to
Cool     communicate with other mortals; via tell to individuals, or group energies can be used
Cool     for group tell. To transmit to a whole clan requires a focus of power not provided by
Cool     the Gods - this burden falls upon those who control clans - it is they
Cool     who have adapted the God's telepathic framework for secretive purposes and provided
Cool     to only those who serve the clan.

poss problems mit AFK and QUIET on the leader

*/
