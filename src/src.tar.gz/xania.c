/*************************************************************************/
/*  Xania (M)ulti(U)ser(D)ungeon server source code                      */
/*  (C) 1995-2000 Xania Development Team                                 */
/*  See the header to file: merc.h for original code copyrights          */
/*                                                                       */
/*  xania.c: a variety of Xania-specific modifications and new utilities */
/*                                                                       */
/*************************************************************************/

/* $Id: xania.c,v 1.15 2000/03/19 12:11:39 phil Exp $ */

#if defined(macintosh)
#include <types.h>
#else
#if defined(riscos)
#include "sys/types.h"
#else
#include <sys/types.h>
#endif
#endif
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "merc.h"
#include "db.h"
#include "interp.h"
#include "magic.h"
#include "buffer.h"

/* $Id: xania.c,v 1.15 2000/03/19 12:11:39 phil Exp $
 */

/*
 * KLUDGEMONGER III, Revenge of Kludgie, the Malicious Code Murderer...
 */


/* tip wizard */

bool ignore_tips;
TIP_TYPE * tip_top;     /* top of and current list item */
TIP_TYPE * tip_current;  


/* report_object, takes an object_index_data obj and a param boot and returns the 'worth' of an
   object in points.  If boot is non-zero it will also 'BUG' these, along with any other things
   that could be wrong with the object */

void objectbug( char *str, OBJ_INDEX_DATA *obj ) {
   char buf[MAX_STRING_LENGTH];
   sprintf( buf,"obj> %s (#%d): %s", obj->short_descr, obj->vnum, str );
   log_string(buf);
}

void mobbug( char *str, MOB_INDEX_DATA *mob) {
   char buf[MAX_STRING_LENGTH];
   sprintf( buf,"mob> %s (#%d): %s", mob->short_descr, mob->vnum, str );
   log_string(buf);
}

int report_object( OBJ_DATA *object , int boot ) {
   int worth = 0, hit=0, dam=0;
   int averagedam, allowedaverage;
   AFFECT_DATA *paf;
   OBJ_INDEX_DATA *obj = object->pIndexData;

   for ( paf=obj->affected ; paf ; paf = paf->next ) {
      switch( paf->location ) {

      default:
         break;

      case APPLY_STR:
      case APPLY_DEX:
      case APPLY_INT:
      case APPLY_WIS:
      case APPLY_CON:
         if (paf->modifier > 0)
            worth+=paf->modifier;
         break;

      case APPLY_HITROLL:
         hit+=paf->modifier;
         break;
      case APPLY_DAMROLL:
         dam+=paf->modifier;
         break;

      case APPLY_SAVING_PARA:
      case APPLY_SAVING_ROD:
      case APPLY_SAVING_PETRI:
      case APPLY_SAVING_BREATH:
      case APPLY_SAVING_SPELL:
      case APPLY_AC:
         if (paf->modifier < 0)
            worth-=paf->modifier;
         break;

      case APPLY_MANA:
      case APPLY_HIT:
      case APPLY_MOVE:
         if (paf->modifier > 0)
            worth+=(paf->modifier+6)/7;
         break;

      }
   }
   /* Weapons are allowed 1 hit and 1 dam for each point */

   if (obj->item_type == ITEM_WEAPON) {
      worth+=(hit+dam)/2;
   }
   else {
      worth+=(hit+dam);
   }

   /* Object specific routines */

   switch (obj->item_type) {

   case ITEM_WEAPON:
      /* Calculate the damage allowed and actual */
      allowedaverage = (object->level/2)+4;
      if (IS_SET(obj->value[4],WEAPON_TWO_HANDS) &&
      IS_SET(obj->wear_flags,ITEM_TWO_HANDS)    )
         allowedaverage+=UMAX(1,(allowedaverage)/20);
      averagedam=(obj->value[1]*obj->value[2]+obj->value[1])/2;
      if ((averagedam > allowedaverage) && boot) {
         objectbug( "average damage too high", obj );
      }
      /* Add to worth for each weapon type */
      if (IS_SET(obj->value[4],WEAPON_FLAMING))
         worth++;
      if (IS_SET(obj->value[4],WEAPON_FROST))
         worth++;
      if (IS_SET(obj->value[4],WEAPON_VAMPIRIC))
         worth++;
      if (IS_SET(obj->value[4],WEAPON_SHARP))
         worth++;
      if (IS_SET(obj->value[4],WEAPON_VORPAL))
         worth++;
      break;

   case ITEM_POTION:
   case ITEM_PILL:
   case ITEM_SCROLL:
   case ITEM_BOMB:
   case ITEM_STAFF:
      if ((obj->value[4] > (object->level+(UMAX(5,obj->level/10)))) && boot)
         objectbug( "level of spell too high", obj );
      break;

   default:
      break;
   }

   if (boot && (worth>((obj->level/10)+1))) {
      char buf[MAX_STRING_LENGTH];
      sprintf( buf, "points too high: has %d points (max should be %d)",worth,
      ((obj->level/10)+1));
      objectbug( buf, obj );
   }
   return worth;
}

/* report_mobile - for checking those not-hard-enough mobs */

void report_mobile( MOB_INDEX_DATA *mob) {

   if ( (mob->damage[DICE_BONUS] + mob->hitroll +
   ((mob->damage[DICE_NUMBER]*mob->damage[DICE_TYPE]+mob->damage[DICE_NUMBER])/2))
   < (mob->level*3/2) )
      mobbug( "can't do enough damage", mob );

   if ( (mob->hit[DICE_NUMBER] + mob->hit[DICE_BONUS]) < (mob->level*30) )
      mobbug( "has too few health points", mob );

   return;
}

/* check_xania - check all of Xania and report those things that aren't what they should be */

void check_xania( void ) {
   OBJ_DATA *object;
   CHAR_DATA *mobile;

   bug( "obj> **********************************************************************" );
   bug( "obj> **               Beginning sweep of all object in Xania             **" );
   bug( "obj> **********************************************************************" );

   for (object=object_list; object; object=object->next) {
      report_object(object,1);
   }


   bug( "obj> **********************************************************************" );
   bug( "obj> **                       Object sweep completed                     **" );
   bug( "obj> **********************************************************************" );

   bug( "mob> **********************************************************************" );
   bug( "mob> **                       Beginning mobile sweep                     **" );
   bug( "mob> **********************************************************************" );

   for (mobile=char_list; mobile; mobile=mobile->next) {
      report_mobile(mobile->pIndexData);
   }

   bug( "mob> **********************************************************************" );
   bug( "mob> **                       Mobile sweep completed                     **" );
   bug( "mob> **********************************************************************" );
}

void do_immworth( CHAR_DATA *ch, char *argument) {
   OBJ_DATA *obj;
   int worth, shouldbe;
   char buf[MAX_STRING_LENGTH];

   if ( (obj = get_obj_world(ch, argument)) == NULL) {
      send_to_char( "Nothing like that in Xania.\n\r", ch);
      return;
   }

   worth = report_object( obj, 0);
   shouldbe = ((obj->level/10)+1);
   if (worth == shouldbe) {
      sprintf(buf, "Object '%s' has %d point(s) - exactly right.\n\r",
      obj->pIndexData->short_descr, worth);
      send_to_char(buf,ch);
      return;
   }
   if (worth > shouldbe) {
      sprintf(buf, "Object '%s' has %d point(s), %d points |Rtoo high|w.\n\r",
      obj->pIndexData->short_descr, worth, (worth-shouldbe));
   }
   else {
      sprintf(buf, "Object '%s' has %d point(s), within the %d point maximum.\n\r",
      obj->pIndexData->short_descr, worth, shouldbe);
   }
   send_to_char(buf, ch);
   return;
}



void set_prefix( CHAR_DATA *ch, char *prefix ) {
   char buf[MAX_STRING_LENGTH];

   strcpy( buf, prefix );

   free_string( ch->pcdata->prefix );
   ch->pcdata->prefix = str_dup( buf );

   return;
}



/* do_prefix added 19-05-97 PCFN */
void do_prefix( CHAR_DATA *ch, char *argument ) {
   CHAR_DATA  *ch_prefix = NULL;
   char        ch_buffer[MAX_STRING_LENGTH];

   if ( strlen(argument) > (MAX_STRING_LENGTH-1) )
      argument[MAX_STRING_LENGTH-1] = '\0';

   if ( IS_NPC(ch) ) {
      if ( ch->desc->original )
         ch_prefix = ch->desc->original;
      else
         return;
   } else ch_prefix = ch;

/* ch_prefix is the character, or the character who is switched into the MOB
   otherwise it's NULL */

   if (ch_prefix==NULL)
   	return;

   smash_tilde( argument );   

   if ( argument[0] == '\0' ) {
      if ( ch_prefix->pcdata->prefix[0] == '\0' ) {
         sprintf( &ch_buffer[0], "No prefix to remove.\n\r");
      } else {
         sprintf( &ch_buffer[0], "Prefix removed.\n\r");
      }
   }

   set_prefix( ch_prefix, argument );
   if ( ch_prefix->pcdata->prefix[0] != '\0' )
      sprintf( &ch_buffer[0], "Prefix set to \"%s\"\n\r", ch_prefix->pcdata->prefix );

   send_to_char( &ch_buffer[0], ch );

   return;
}



/* do_timezone added PCFN 24-05-97 */
void do_timezone( CHAR_DATA *ch, char *argument ) {
   CHAR_DATA  *ch_owner = NULL;
   char        buf[64];

   if ( IS_NPC(ch) ) {
      if ( ch->desc->original )
         ch_owner = ch->desc->original;
      else
         return;
   } else ch_owner = ch;

   if ( argument[0] == '\0' ) {
      if ( ch_owner->pcdata->minoffset  == 0 &&
           ch_owner->pcdata->houroffset == 0 )
         send_to_char( "British time is already being used\n\r", ch_owner );
      else {
         send_to_char( "British time will be used\n\r", ch_owner );
         ch_owner->pcdata->minoffset   = 0;
         ch_owner->pcdata->houroffset  = 0;
      }
   } else {
      sscanf( argument, "%d:%d", (int *)&(ch_owner->pcdata->houroffset), (int *)&(ch_owner->pcdata->minoffset) );
      sprintf( buf, "Time will now be displayed %d:%2d from GMT\n\r",
               ch_owner->pcdata->houroffset, ch_owner->pcdata->minoffset );
      send_to_char( buf, ch_owner );
   }

   return;
}


 
/********************************************************************************************/


/*****************************************
 ******************************************************************/
int get_skill_level( CHAR_DATA *ch, int gsn ) {
   int level=0,bonus;


   if ( IS_NPC(ch) ) {

     if (ch->desc) {                       /* Is this a switched IMM? */
       if ( (ch = ch->desc->original) == NULL) {
	 return 1;
       }
     } else {  /* A genuine NPC */
       return 1;
     }
   }

   /* First we work out which level they'd get it at because of their class */

   if (skill_table[gsn].rating[ch->class] > SKILL_UNATTAINABLE) {
                                /*  They *can* get it at level xxxx */
      level=skill_table[gsn].skill_level[ch->class];
   }
   if (skill_table[gsn].rating[ch->class] == SKILL_ATTAINABLE) {
                                /*  They get it at level sixty */
      level=60;
   }
   if (skill_table[gsn].rating[ch->class] == SKILL_ASSASSIN) {
                                          /*  It's an assassin thing */
      if (ch->pcdata->group_known[group_lookup("assassin")]) {
         /*  they have the group so they get the skill at level 30 */
         level=30;
      }
      else                      /*  They got the skill on its own */
         level=60;
   }


   /* Check stuff because of race */
   for (bonus=0; bonus<5; bonus++) {
      if (pc_race_table[ch->race].skills[bonus] != NULL) {
         /* they have a bonus skill or group */
         if (skill_lookup(pc_race_table[ch->race].skills[bonus]) == gsn) {
            /* ie we have a race-specific skill!! */
            if (level>30)
               level=30;   /*obviously*/
         }
      }
   }
   return level;
}


/*****************************************/
int get_skill_difficulty( CHAR_DATA *ch, int gsn) {
   int level,hard,bonus;

   if ( (level=get_skill_level(ch,gsn)) == 0)  /* ie you can't gain it ever! */
      return 0;

   if (level > ch->level)
      return 0;                 /* as you're not high enough level */

   hard = skill_table[gsn].rating[ch->class];
   switch (hard) {
   case SKILL_UNATTAINABLE:
      return 0;         /* this should never happen as get_skill_level does this */
   case SKILL_ATTAINABLE:
      hard=8;           /* skills at level 60 */
   case SKILL_ASSASSIN:
      hard=5;           /* Assassin group stuff */
   }
   /* Check for race skills */
   for (bonus=0; bonus<5; bonus++) {
      if (pc_race_table[ch->race].skills[bonus] != NULL) {
         /* they have a bonus skill or group */
         if (skill_lookup(pc_race_table[ch->race].skills[bonus]) == gsn) {
            /* ie we have a race-specific skill!! */
            if (hard>2)
               --hard;  /* Make it a bit easier */
         }
      }
   }
   return hard;
}


/*****************************************/
int get_skill_trains( CHAR_DATA *ch, int gsn) {
   int number;
   if ( (number=get_skill_level(ch,gsn)) >= 60 && (ch->level<60))
      /* can't show it */
      return 0;

   if (skill_table[gsn].spell_fun != spell_null)
      return 0;

   switch(skill_table[gsn].rating[ch->class]) {
   case SKILL_UNATTAINABLE:
      return 0; /* shouldn't happen */
   case SKILL_ATTAINABLE:
      return 10;  /* $-) */
   case SKILL_ASSASSIN:
      return 10;
   }
   return(skill_table[gsn].rating[ch->class]);
}

// New skill learned function - use instead of looking it up directly in the pcdata!!
// Similar to get_skill
int get_skill_learned (CHAR_DATA *ch, int skill_number)
{
     // Mobs calling this get either 100 or 90
     if (IS_NPC(ch)) {
	  if (is_affected (ch, gsn_insanity))
	       return 90;
	  else
	       return 100;
     } else {
	  if (is_affected (ch, gsn_insanity))
	       return (9 * ch->pcdata->learned[skill_number]) / 10;
	  else
	       return ch->pcdata->learned[skill_number];
     }
}


/*****************************************
 ******************************************************************/
int get_group_trains( CHAR_DATA *ch, int gsn) {
   int number;
   if ( (number=get_group_level(ch,gsn)) >= 60 && (ch->level < 60))
      /* can't show it */
      return 0;

   switch(group_table[gsn].rating[ch->class]) {
   case 0:
      return 0;
   case -1:
      return 20;  /* $-) */
   case -2:
   case -3:
      return 0;
   }
   return(group_table[gsn].rating[ch->class]);
}

int get_group_level( CHAR_DATA *ch, int gsn ) {
   switch(group_table[gsn].rating[ch->class]) {
   case 0:
      return 0;
   case -1:
      return 60;
   case -2:
   case -3:
      return 0;
   default:
      return(group_table[gsn].rating[ch->class]);
   }
}


/********************************************************************************************/

/*****************************************
 ******************************************************************/
int is_made_of(OBJ_DATA *obj, char *material);

int check_material_vulnerability( CHAR_DATA *ch, OBJ_DATA *object ) {

   if (IS_SET(ch->vuln_flags, VULN_WOOD)) {
      if (is_made_of(object,"wood"))
         return 1;
   }

   if (IS_SET(ch->vuln_flags, VULN_SILVER)) {
      if (is_made_of(object,"silver"))
         return 1;
   }

   if (IS_SET(ch->vuln_flags, VULN_IRON)) {
      if (is_made_of(object,"iron"))
         return 1;
   }
   return 0;
}

int is_made_of(OBJ_DATA *obj, char *material) {
   if (!str_cmp(material_table[obj->pIndexData->material].material_name, material))
      return 1;
   return 0;
}

/********************************************************************************************/

/*****************************************
 ******************************************************************/

void spell_reincarnate( int sn, int level, CHAR_DATA *ch, void *vo) {
   /* is of type TAR_IGNORE so ignore *vo */

   OBJ_DATA *obj;
   int num_of_corpses=0, corpse, chance;

   if (IS_NPC(ch))
      return;

   /* scan the room looking for an appropriate objects...count them */
   for (obj=ch->in_room->contents ; obj ; obj=obj->next_content) {
      if (    (obj->pIndexData->item_type==ITEM_CORPSE_NPC)
      || (obj->pIndexData->item_type==ITEM_CORPSE_PC)   )
         num_of_corpses++;
   }

   /* Did we find *any* corpses? */
   if (num_of_corpses==0) {
      send_to_char("There are no dead in this room to reincarnate!\n\r",ch);
      return;
   }

   /* choose a corpse at random & find it's corresponding OBJ_DATA */
   corpse = number_range(1,num_of_corpses);
   for (obj=ch->in_room->contents ; obj ; obj=obj->next_content) {
      if (    (obj->pIndexData->item_type==ITEM_CORPSE_NPC)
      || (obj->pIndexData->item_type==ITEM_CORPSE_PC)   ) {
         if (--corpse==0)
            break;
      }
   }

   if (obj==NULL) {/* Oh dear */
      bug("spell_reincarnate: Couldn't find corpse!");
      return;
   }

   /* Tell people what happened */
   act("$n summons mighty powers and reanimates $s.",ch,NULL,obj, TO_ROOM);
   act("You summon mighty powers and reanimate $s.",ch,NULL,obj, TO_CHAR);

   /* Can we re-animate this corpse? Include check for a non-empty PC corpse */

   chance=URANGE(1,(50+((ch->level - obj->pIndexData->level)*3)),99);

   if ((number_percent() > chance) ||  /* if random failed */
   ((obj->pIndexData->item_type == ITEM_CORPSE_PC) && (obj->contains != NULL)))
   /* if non-empty PC corpse */ {
      act("$s stands, then falls over again - lifeless.",ch,NULL,obj, TO_ROOM);
      act("$s stands, then falls over again - lifeless.",ch,NULL,obj, TO_CHAR);
      return;
   }
   else {
      char buf[MAX_STRING_LENGTH];
      CHAR_DATA *animated;

      act("$s stands up.",ch,NULL,obj, TO_ROOM);
      act("$s stands up.",ch,NULL,obj, TO_CHAR);
      animated = create_mobile( get_mob_index(MOB_VNUM_ZOMBIE) );
      if (animated==NULL) {
         bug("spell_reincarnate: Couldn't find corpse vnum!");
         return;
      }

      /* Put the zombie in the room */
      char_to_room(animated,ch->in_room);
      /* Give the zombie the kit that was in the corpse */
      animated->carrying = obj->contains;
      obj->contains = NULL;
      /* Give the zombie its correct name and stuff */
      sprintf(buf, animated->description, obj->description);
      free_string(animated->long_descr);
      animated->long_descr = str_dup(buf);
      sprintf(buf, animated->name, obj->name);
      free_string(animated->name);
      animated->name = str_dup(buf);

      /* Say byebye to the corpse */
      extract_obj(obj);

      /* Set up the zombie correctly */
      animated->master=ch;
      animated->leader=ch;
      do_follow(animated, ch->name);
   }
}

void do_smit ( CHAR_DATA *ch, char *argument) {

   send_to_char ("If you wish to smite someone, then SPELL it out!\n\r" , ch);
   return;
}

void do_smite ( CHAR_DATA *ch, char *argument) {
   /* Power of the Immortals! By RjS aka Faramir
                                Don't use this too much, it hurts :) */

   char      *smitestring;
   char      smitebuf[MAX_STRING_LENGTH];
   CHAR_DATA *victim;
   OBJ_DATA  *obj;

   if ( argument[0] == '\0') {
      send_to_char( "Upon whom do you wish to unleash your power?\n\r", ch);
      return;
   }

   if ( ( victim = get_char_room( ch, argument ) ) == NULL ) {
      send_to_char( "They aren't here.\n\r", ch );
      return;
   }                   /* Not (visibly) present in room! */

   /* In case a mort thinks he can get away
   			    with it, shah right! MMFOOMB
   			    Should be dealt with in interp.c already*/


   if ( IS_NPC ( ch ) ) {
      send_to_char ("You must take your true form before unleashing your power.\n\r" , ch);
      return;
   }                   /* done whilst switched? No way Jose */

   if (get_trust ( victim ) > get_trust ( ch ))  {


      send_to_char ("You failed.\n\rUmmm...beware of retaliation!\n\r" , ch);
      act( "$n attempted to smite $N!",  ch, NULL, victim, TO_NOTVICT);
      act( "$n attempted to smite you!", ch, NULL, victim, TO_VICT);
      return;
   }
   /* Immortals cannot smite those with a
   			    greater trust than themselves */

   smitestring="__NeutralSmite";

   if (ch->alignment >= 300)  {
      smitestring="__GoodSmite" ;
   }                   /* Good Gods */
   if (ch->alignment <= - 300)  {
      smitestring="__BadSmite" ;
   }                   /* Establish what message will actually
   			    be sent when the smite takes place.
   			    Evil Gods have their own evil method of
   			    incurring their wrath, and so neutral and
   			    good Gods =)  smitemessage default of 0
   			    for neutral. */

   /* ok, now the appropriate smite
                                          string has been determined we must
                                          send it to the victim, and tell
                                          the smiter and others in the room. */

   do_help(victim,smitestring);
   act ( "|WThe wrath of the Gods has fallen upon you!\n\rYou are blown helplessly from your feet and are stunned!|w", ch, NULL, victim, TO_VICT );

   if ( ( obj = get_eq_char( victim, WEAR_WIELD ) ) == NULL ) {
      act ("|R$n has been cast down by the power of $N!|w",
      victim, NULL, ch, TO_NOTVICT);
   }
   else {
      act ("|R$n has been cast down by the power of $N!\n\rTheir weapon is sent flying!|w", victim, NULL, ch, TO_NOTVICT);
   }

   /* tells others that the victim has
                                           been disarmed, but not the victim :) */

   sprintf(smitebuf, "You |W>>> |YSMITE|W <<<|w %s with all of your Godly powers!\n\r", (victim==ch)? "yourself" : victim->name);
   send_to_char (smitebuf,ch);

   victim->hit/=2;            /* easiest way of halving hp? */
   if (victim->hit < 1)
      victim->hit=1;           /* Cap the damage */

   victim->position = POS_RESTING;
   /* Knock them into resting
                                           and disarm them regardless of whether
                                           they have talon or a noremove weapon */

   if ( ( obj = get_eq_char( victim, WEAR_WIELD ) ) == NULL ) {
      return;
   }                       /* can't be disarmed if no weapon */
   else {
      obj_from_char( obj );
      obj_to_room( obj, victim->in_room );
      if (IS_NPC(victim) && victim->wait == 0 && can_see_obj(victim,obj))
         get_obj(victim,obj,NULL);
   }                               /* disarms them, and NPCs will collect
                                           their weapon if they can see it.
                                           Ta-daa, smite compleeeeeet. Ouch. */
   return;
}


/* web related functions */

bool web_see ( CHAR_DATA * ch ) {
	
	if( IS_SET( ch->act, PLR_WIZINVIS )||
	    IS_SET( ch->act, PLR_PROWL ) ||
	    IS_SET( ch->act, PLR_AFK ) ||
	    IS_AFFECTED( ch, AFF_INVISIBLE ) ||
	    IS_AFFECTED( ch, AFF_SNEAK ) ||
	    IS_AFFECTED( ch, AFF_HIDE ))
		return FALSE;
	else 
		return TRUE;
}
	   



void web_who ( void ) {

	FILE * fp;
	DESCRIPTOR_DATA *d;
	int count =0;

	if(( fp = fopen( WEB_WHO_FILE, "w" )) == NULL ) {
		bug( "web_who: couldn't open %s for writing!", WEB_WHO_FILE );
		return;
	}
	fprintf( fp,"<HTML><HEAD><TITLE TEXT=\"#FFFFFF\">Who's playing Xania right now?</TITLE>"
		 "</HEAD><BODY BGCOLOR=\"#000000\" TEXT=\"#FFAA44\">"
		 "<CENTER><H2>Who's playing Xania right now?</H2><P></CENTER>"
		 "<TABLE BORDER=0>"

	);
	fprintf( fp, "<b><TR><TD>Level</TD> <TD>Race</TD> <TD>Class</TD>  <TD>Who</TD></TR></b>\n" );

	for ( d = descriptor_list; d != NULL; d = d->next )
		{
			CHAR_DATA *wch;
			
			wch = ( d->original != NULL ) ? d->original : d->character ;
			
			if ( d->connected != CON_PLAYING || 
			     !web_see( wch ))
				continue;
			fprintf( fp, "<TR><TD>%d</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD><TD>%s</TD>\n",
				 wch->level,
				 wch->race < MAX_PC_RACE ? pc_race_table[wch->race].who_name
				 : "     ",    
				 class_table[wch->class].name,
				 wch->name,
				 wch->pcdata->title );
			count++;
			
		}
	fprintf( fp, "</TABLE>"
		 "<P>Players found: %d <ADDRESS>Generated by Xania MUD. faramir@xania.demon.co.uk</ADDRESS></BODY></HTML>\n", count );
	
	
	fclose( fp );
	return;
}


void load_tipfile(void ) {

	FILE * fp = NULL;
	int tipcount = 0;
        TIP_TYPE *ptt = NULL;
	
	tip_top = tip_current = NULL; /* initialise globals */
	
	if(( fp = fopen( TIPWIZARD_FILE, "r" )) == NULL ) {
		bug( "Couldn't open tip file \'%s\' for reading", 
		     TIPWIZARD_FILE );
		ignore_tips = TRUE;
		return;
	}
	for( ; ; ) {
		char c;
		ptt = NULL;
		
		while( isspace( c = getc(fp)));
		ungetc(c,fp);
		if( feof(fp)) {
			fclose( fp );
			bug( "Loaded %d tips", tipcount ); /* not really a bug! */
			if( tipcount == 0 )
				ignore_tips = TRUE; /* don't bother polling the tip loop*/
			tip_current = tip_top;
			return;
		}
		ptt = (TIP_TYPE*) malloc( sizeof(TIP_TYPE ));
		ptt->next =NULL;
		ptt->tip = fread_string( fp );
		
		if( tip_top == NULL ) {
			tip_top = ptt;
			tip_current = tip_top;
		}
		else 
			tip_current->next = ptt;
		tip_current = ptt;
		tipcount++;
	}
	/* now set the current tip to the top of the list ready for use*/
	return;
}

void tip_players(void) {

	
	DESCRIPTOR_DATA *d;
	char buf[MAX_STRING_LENGTH];
	
	/* check the tip wizard list first ... */

	if( tip_current == NULL )
		tip_current = tip_top; /* send us back to top of list */

	if( tip_top == NULL ) {  /* we didn't load a tip file so ignore */
		ignore_tips = TRUE;
		return;
	}
	if( tip_current->tip == NULL ) {
		tip_current = tip_current->next;
		return;
	}
	if( strlen( tip_current->tip ) == 0) {
		tip_current = tip_current->next;
		return;
	}
	sprintf( buf, "|WTip: %s|w\n\r", tip_current->tip );
     	for( d = descriptor_list ; d != NULL ; d = d->next) {
		CHAR_DATA * ch;
			
		ch = ( d->original != NULL ) ? d->original : d->character ;
		
		if ( d->connected != CON_PLAYING )
			continue;
		     
		if( is_set_extra( ch, EXTRA_TIP_WIZARD )) {
			send_to_char( buf, ch );
		}
	}
	tip_current = tip_current->next;
	
	return;
}

void do_tipwizard( CHAR_DATA *ch, char * arg ) { 

	if( arg[0] == '\0' ) {
		if( is_set_extra( ch, EXTRA_TIP_WIZARD )) {
			remove_extra( ch, EXTRA_TIP_WIZARD);
			send_to_char( "Tipwizard deactivated.\n\r", ch );
		}
		else {
			set_extra( ch, EXTRA_TIP_WIZARD );
			send_to_char( "Tipwizard activated!\n\r", ch );
		}
		return;
	}
	if(!strcmp( arg, "on" )) {
		set_extra( ch, EXTRA_TIP_WIZARD );
		send_to_char( "Tipwizard activated!\n\r", ch );
		return;
	}
	if(!strcmp( arg, "off" )) {
		remove_extra( ch, EXTRA_TIP_WIZARD );
		send_to_char( "Tipwizard deactivated.\n\r", ch );
		return;
	}
	send_to_char( "Syntax: tipwizard {on/off}\n\r", ch );
	return;
	
}

