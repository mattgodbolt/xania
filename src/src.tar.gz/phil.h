/************************************************************************/
/*  Xania (M)ulti(U)ser(D)ungeon server source code                     */
/*  (C) 1995-2000 Xania Development Team                                   */
/*  See the header to file: merc.h for original code copyrights         */
/*                                                                      */
/*  phil.c:  special functions for Phil the meerkat						*/
/*																		*/
/************************************************************************/


/* $Id: phil.h,v 1.4 2000/02/27 23:08:24 rob Exp $ */

/* function declarations */
bool spec_phil( CHAR_DATA *ch );
